﻿using System;
using Entitas;
using UnityEngine;

public sealed class $safeitemname$ : IExecuteSystem
{

    readonly Context _context;

    public $safeitemname$(Contexts contexts)
    {
        _context = contexts.game;
    }

    public void Execute()
    {
        throw new NotImplementedException();
    }
}

