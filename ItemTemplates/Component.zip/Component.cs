﻿using Entitas;

[Game]
public sealed class $safeitemname$ : IComponent{
}

