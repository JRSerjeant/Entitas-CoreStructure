﻿using System;
using System.Collections.Generic;
using Entitas;
using UnityEngine;

class $safeitemname$ : ReactiveSystem
{

    public $safeitemname$(Contexts contexts) : base(contexts.game){
    }

    protected override void Execute(List<Entity> entities)
    {
        throw new NotImplementedException();
    }

    protected override bool Filter(Entity entity)
    {
        throw new NotImplementedException();
    }

    protected override Collector GetTrigger(Context context)
    {
        throw new NotImplementedException();
    }
}

