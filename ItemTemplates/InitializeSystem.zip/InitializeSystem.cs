﻿using System;
using Entitas;

class $safeitemname$ : IInitializeSystem
{
    readonly Context _context;

    public $safeitemname$(Contexts contexts)
    {
        _context = contexts.game;
    }


    public void Initialize()
    {
        throw new NotImplementedException();
    }
}

